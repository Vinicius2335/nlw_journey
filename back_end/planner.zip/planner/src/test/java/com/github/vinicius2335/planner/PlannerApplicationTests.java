package com.github.vinicius2335.planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
